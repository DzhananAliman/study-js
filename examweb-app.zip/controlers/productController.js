const express = require('express');
const Product = require('../models/Product');
const router = express.Router();
const isAuth = require('../middlewares/auth');

// Показване на всички продукти
router.get('/', async (req, res) => {
  const products = await Product.find();
  const user = req.session.user;

  res.render('products/index', { title: "Products", user, products });
});

router.get('/create', isAuth, async (req, res) => {
  const user = req.session.user;
  res.render("products/create", { title: "Create Product", user, post: null, error: null });
});

router.get('/details/:id', async (req, res) => {
  const { id } = req.params;

  const product = await Product.findById(id);

  if (!product) {
    return res.redirect("/products");
  }

  const user = req.session.user;
  res.render("products/details", { title: product.name, user, product });
});

router.post('/create', isAuth, async (req, res) => {
  const { name, skin, description, ingredients, benefits, price, imageUrl } = req.body;
  const user = req.session.user;

  if (!name || !skin || !description || !ingredients || !benefits || !price || !imageUrl) {
    return res.render("products/create", {
      title: "Create Product",
      user,
      post: req.body,
      error: "All fields are required"
    });
  }

  const userId = user._id;
  const product = new Product({ name, skin, description, ingredients, benefits, price, imageUrl, userId });
  await product.save();

  res.redirect("/products");
});

router.get('/edit/:id', isAuth, async (req, res) => {
  const { id } = req.params;

  const product = await Product.findById(id);

  if (!product) {
    return res.redirect("/products");
  }

  const user = req.session.user;
  res.render("products/edit", { title: product.name, user, product, error: null });
});

router.post('/edit/:id', isAuth, async (req, res) => {
  const { id } = req.params;

  try {
    const product = await Product.findById(id);

    if (!product) {
      return res.redirect("/products");
    }

    const { name, skin, description, ingredients, benefits, price, imageUrl } = req.body;
    const user = req.user;

    if (!name || !skin || !description || !ingredients || !benefits || !price || !imageUrl) {
      return res.render("products/edit", {
        title: "Edit Product",
        user,
        post: req.body,
        error: "All fields are required"
      });
    }

    await Product.updateOne({ _id: id }, { ...req.body });

    res.redirect(`/products/details/${product._id}`);
  } catch (err) {
    console.error("Error updating product:", err);
    res.status(500).send("Something went wrong while updating the product.");
  }
});

router.get("/delete/:id", isAuth, async (req, res) => {
  const { id } = req.params;

  const product = await Product.findById(id);

  if (!product || product.userId != req.user._id) {
    return res.redirect("/products");
  }
  
  await Product.deleteOne({ _id: id });

  res.redirect("/products");
});

module.exports = router;