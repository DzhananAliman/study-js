const express = require('express');
const Post = require('../models/Post');
const router = express.Router();

// Създаване на нов пост
router.get('/create', (req, res) => {
  res.render('create-post');
});

router.post('/create', async (req, res) => {
  const { title, content, productId } = req.body;
  const post = new Post({
    title,
    content,
    author: req.session.user._id,
    product: productId
  });

  await post.save();
  res.redirect('/');
});

module.exports = router;
