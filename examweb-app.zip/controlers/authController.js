const express = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const router = express.Router();

// Регистрация
router.get('/register', (req, res) => {
  res.render('register', { title: "Register", user: null });
});

// Вход
router.get('/login', (req, res) => {
  res.render('login', { title: "Login", user: null });
});

router.post('/register', async (req, res) => {
  const { name, email, password, 're-password': rePassword } = req.body;

  if (password !== rePassword) {
    return res.send('Passwords do not match');
  }

  const user = new User({ name, email, password });
  await user.save();
  res.redirect('/login');
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (!user) {
    return res.send('Invalid email or password');
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.send('Invalid email or password');
  }

  req.session.user = user;
  res.redirect('/');
});

// Изход
router.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});

module.exports = router;
