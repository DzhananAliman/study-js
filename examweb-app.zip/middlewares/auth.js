function isAuth(req, res, next) {
    const user = req.session.user;

    if (!user) {
        return res.redirect("/login");
    }

    req.user = user;
    
    next();
}

module.exports = isAuth;
