const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const expressLayouts = require('express-ejs-layouts');

const app = express();

// Свързване с MongoDB без старите опции
mongoose.connect('mongodb+srv://demo:demo@cluster0.jtmw5.mongodb.net')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.log(err));

// Настройки на express
app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('layout', 'layouts/layout');

app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

app.use(
  session({
    secret: 'your-secret-key', // Трябва да е дълга и уникална стойност
    resave: false, // Не запазва сесията, ако не е променена
    saveUninitialized: false, // Не създава празни сесии
    cookie: {
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 дни
      httpOnly: true,
      secure: false, // Задайте `true`, ако използвате HTTPS
    },
  })
);


// Сесии
app.use(session({
  secret: 'yourSecretKey',
  resave: false,
  saveUninitialized: true
}));

// Пътеките за контролери
const authRoutes = require('./controlers/authController');
const postRoutes = require('./controlers/postController');
const productRoutes = require('./controlers/productController');

// Използване на маршрути
app.use('/', authRoutes);
app.use('/posts', postRoutes);
app.use('/products', productRoutes);

app.get('/', (req, res) => {
  const user = req.session.user;
  res.render("index", { title: "Home", user });
});

// Грешка при невалидни пътеки
app.use((req, res, next) => {
  res.status(404).render('not-found', { user: req.session.user });
});

// Стартиране на сървъра
app.listen(5000, () => {
  console.log('Server is running on http://localhost:5000');
});
