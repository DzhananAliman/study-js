<?php

require "core/Autoloader.php";

define("host", "localhost");
define("db_name", "users_demo");
define("username", "root");
define("password", "password");

$db = new DatabaseConnection(
    host,
    db_name,
    username,
    password
);

require "routers/index.php";