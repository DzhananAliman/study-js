<?php

class IndexGetController
{
    public static function Home()
    {
        require "views/index/home.php";
        exit;
    }

    public static function About()
    {
        require "views/index/about.php";
        exit;
    }
}
