<?php

class UserGetController
{
    public static function Register()
    {
        Setup::View("users/register");
    }

    public static function Login()
    {
        Setup::View("users/login");
    }
}