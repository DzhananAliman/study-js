<?php

class UserPostController
{
    public static function Register()
    {
        $postData = $_POST;
        $_SESSION["post"] = $postData;

        if (empty($postData["email"]) || empty($postData["password"]) || empty($postData["cpassword"])) {
            $_SESSION["error_message"] = "Всички полета са задължителни!";
            UserGetController::Register();
        }
        
        if (!filter_var($postData["email"], FILTER_VALIDATE_EMAIL)) {
            $_SESSION["error_message"] = "Моля, въведете валиден имейл адрес!";
            UserGetController::Register();
        }

        if ($postData["password"] !== $postData["cpassword"]) {
            $_SESSION["error_message"] = "Паролите не съвпадат!";
            UserGetController::Register();
        }

        global $db;

        $users = $db->read("users", ["email" => $postData["email"]]);
        if (count($users) > 0) {
            $_SESSION["error_message"] = "Това имейл адрес е зает!";
            UserGetController::Register();
        }

        $db->create("users", [
            "email" => $postData["email"],
            "password" => password_hash($postData["password"], PASSWORD_DEFAULT),
        ]);
        $db->commit();

        Setup::redirect("/users/login");
    }
}
