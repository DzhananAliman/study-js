<?php require "views/partials/head.php"; ?>

<h1 class="text-center text-3xl font-bold my-10">Влезте в профила си</h1>

<div class="container mx-auto max-w-md border shadow-sm rounded p-10">
    <form action="/users/login" method="POST" class="grid gap-5">
        <div>
            <label for="email" class="block mb-2">Имейл:</label>
            <input class="border border-gray-400 rounded py-2 px-5 block w-full" type="email" name="email" id="email">
        </div>
        <div>
            <label for="password" class="block mb-2">Парола:</label>
            <input class="border border-gray-400 rounded py-2 px-5 block w-full" type="password" name="password" id="password">
        </div>
        <div>
            <button class="primary-button w-full py-2 px-5 rounded" type="submit">Вход</button>
        </div>
    </form>
</div>

<?php require "views/partials/head.php"; ?>
