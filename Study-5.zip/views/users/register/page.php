<?php require "views/partials/head.php"; ?>

<?php
    $post = $_SESSION["post"] ?? null;
    unset($_SESSION["post"]);
?>

<h1 class="text-center text-3xl font-bold my-10">Регистрация</h1>

<div class="container mx-auto max-w-md border shadow-sm rounded p-10">
    <?php if (!empty($_SESSION["error_message"])): ?>
        <div class="bg-red-200 p-5 mb-5 rounded">
            <?= $_SESSION["error_message"] ?>
        </div>
        <?php unset($_SESSION["error_message"]) ?>
    <?php endif; ?>

    <form action="/users/register" method="POST" class="grid gap-5">
        <div>
            <label for="email" class="block mb-2">Имейл:</label>
            <input class="border border-gray-400 rounded py-2 px-5 block w-full" type="text" name="email" value="<?= $post["email"] ?? "" ?>" id="email">
        </div>
        <div>
            <label for="password" class="block mb-2">Парола:</label>
            <input class="border border-gray-400 rounded py-2 px-5 block w-full" type="password" name="password" value="<?= $post["password"] ?? "" ?>" id="password">
        </div>
        <div>
            <label for="cpassword" class="block mb-2">Потвърдете паролата:</label>
            <input class="border border-gray-400 rounded py-2 px-5 block w-full" type="password" name="cpassword" value="<?= $post["cpassword"] ?? "" ?>" id="cpassword">
        </div>
        <div>
            <span>Съгласявам се с</span>
            <a href="/terms" class="text-link">Общите условия</a>
            <span> и </span>
            <a href="/privacy-policy" class="text-link">Политиката за поверителност</a>
        </div>
        <div>
            <button class="primary-button w-full py-2 px-5 rounded" type="submit">Register</button>
        </div>
    </form>
</div>

<?php require "views/partials/head.php"; ?>
