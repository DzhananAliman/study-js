const formFields = ["name", "email", "password"];
const usersList = document.getElementById("users");

let counter = 0;

const form = document.querySelector("form");

form.addEventListener("submit", send);

function send(event) {
    event.preventDefault();
    counter++;
    let values = {};

    formFields.forEach((element, index) => {
        values[element] = form[element].value;
    });

    if (!form.name.value) {
        alert("Name is required!");
        return;
    }
    
    const listItem = document.createElement("li");
    listItem.innerHTML = `
        <li data-id="${counter}">
            <div>
                <span>Name:</span>
                <span>${values.name}</span>
            </div>
            <div>
                <span>Email:</span>
                <span>${values.email}</span>
            </div>
            <div>
                <span>Password:</span>
                <span>${values.password}</span>
            </div>
            <button onclick="deleteItem(${counter})">Delete</button>
        </li>
    `;

    usersList.appendChild(listItem);
}

function deleteItem(id) {
    const listItem = usersList.querySelector(`li [data-id="${id}"]`);
    listItem.remove();
}