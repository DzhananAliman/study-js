<?php

$router->get("/users/register", ["UserGetController", "Register"]);
$router->get("/users/login", ["UserGetController", "Login"]);

$router->post("/users/register", ["UserPostController", "Register"]);