<?php

$router = new Router();

$uri = $_SERVER["REQUEST_URI"];
$method = $_SERVER["REQUEST_METHOD"];

$router->get("/", ["IndexGetController", "Home"]);
$router->get("/about", ["IndexGetController", "About"]);

require "users.php";

$router->route($uri, $method);
